// Vercel Serverless Function: POST /api/contact
// Sends contact-form messages to your inbox using Resend (free tier: 3,000 emails/month).
// No npm packages needed — uses the built-in fetch in Node 18+.
//
// Environment variables (set in Vercel → Project → Settings → Environment Variables):
//   RESEND_API_KEY    required  – from https://resend.com/api-keys
//   CONTACT_TO_EMAIL  optional  – where messages go (default: arunpratap.rv007@gmail.com)
//   CONTACT_FROM      optional  – sender (default: "Portfolio <onboarding@resend.dev>")

const hits = new Map(); // simple per-instance rate limit
const WINDOW_MS = 10 * 60 * 1000;
const MAX_PER_WINDOW = 5;

const esc = (s = '') =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Use POST to send a message.' });
  }

  // Rate limit by IP
  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= MAX_PER_WINDOW) {
    return res.status(429).json({ error: 'Too many messages in a short time. Try again in 10 minutes.' });
  }
  recent.push(now);
  hits.set(ip, recent);

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch { body = {}; }
  }
  const { name = '', email = '', company = '', topic = '', message = '', website = '' } = body || {};

  // Honeypot: bots fill the hidden "website" field. Pretend success.
  if (website) return res.status(200).json({ ok: true });

  const n = String(name).trim().slice(0, 100);
  const e = String(email).trim().slice(0, 150);
  const c = String(company).trim().slice(0, 120);
  const t = String(topic).trim().slice(0, 60) || 'Website enquiry';
  const m = String(message).trim().slice(0, 3000);

  if (!n || !m) return res.status(400).json({ error: 'Name and message are required.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) return res.status(400).json({ error: 'Enter a valid email address.' });

  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.error('RESEND_API_KEY is not set');
    return res.status(500).json({ error: 'The contact form is not configured yet.' });
  }

  const to = process.env.CONTACT_TO_EMAIL || 'arunpratap.rv007@gmail.com';
  const from = process.env.CONTACT_FROM || 'Portfolio <onboarding@resend.dev>';

  const html = `
    <div style="font-family:Arial,sans-serif;max-width:600px">
      <h2 style="margin:0 0 12px">New message from your portfolio</h2>
      <p><b>Name:</b> ${esc(n)}</p>
      <p><b>Email:</b> ${esc(e)}</p>
      ${c ? `<p><b>Company:</b> ${esc(c)}</p>` : ''}
      <p><b>Topic:</b> ${esc(t)}</p>
      <p><b>Message:</b></p>
      <p style="white-space:pre-wrap;background:#f4f6fb;padding:14px;border-radius:8px">${esc(m)}</p>
    </div>`;

  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from,
        to: [to],
        reply_to: e,
        subject: `Portfolio: ${t} — ${n}`,
        html,
        text: `Name: ${n}\nEmail: ${e}\nCompany: ${c}\nTopic: ${t}\n\n${m}`,
      }),
    });
    if (!r.ok) {
      console.error('Resend error', r.status, await r.text());
      return res.status(502).json({ error: 'The email service rejected the message.' });
    }
    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('Send failed', err);
    return res.status(500).json({ error: 'The message could not be sent.' });
  }
}
